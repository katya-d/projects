using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DGTCalc
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, DTG User!");

            Console.WriteLine("Въведи броя символи на текста (например 1000)");
            var symbols = double.Parse(Console.ReadLine());

            Console.WriteLine("Въведи времетраенето на аудио записа в секунди (например 200)");

            var audioSeconds = double.Parse(Console.ReadLine());

            var symbPerSecond = symbols / audioSeconds;

            var totalSec = 1800 / symbPerSecond;

            TimeSpan t = TimeSpan.FromSeconds(totalSec);

            Console.WriteLine(" ");

            Console.WriteLine("РЕЗУЛТАТИ: ");

            Console.WriteLine(" ");

            Console.WriteLine("Брой символи за секунда: " + symbPerSecond);

            Console.WriteLine(" ");

            Console.WriteLine("Резултат в секунди: " + totalSec);

            Console.WriteLine(" ");

            Console.WriteLine("1800 символа са изговорени приблизително за " + t.Minutes + " : " + t.Seconds + " минути ");


        }
    }
}
